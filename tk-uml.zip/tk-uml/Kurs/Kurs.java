
import java.util.*;

/**
 * 
 */
public class Kurs {

    /**
     * Default constructor
     */
    public Kurs() {
    }

    /**
     * 
     */
    public void termin;

    /**
     * 
     */
    public void thema;


}