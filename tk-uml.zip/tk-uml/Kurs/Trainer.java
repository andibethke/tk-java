
import java.util.*;

/**
 * 
 */
public class Trainer extends Person {

    /**
     * Default constructor
     */
    public Trainer() {
    }


}