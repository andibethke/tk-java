
import java.util.*;

/**
 * 
 */
public class Teilnehmer extends Person {

    /**
     * Default constructor
     */
    public Teilnehmer() {
    }



}