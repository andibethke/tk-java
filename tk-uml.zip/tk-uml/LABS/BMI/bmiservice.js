var http=require("http");
var url=require("url");

class Mitarbeiter{
    constructor(groesse=0.0,gewicht=0.0){
        this.groesse=groesse;
        this.gewicht=gewicht;
    }
    berecheBmi(){
        return this.gewicht/(this.groesse*this.groesse);
    }
    isPraemie(){
        let bmi=this.berecheBmi();
        return bmi>19 && bmi<24;
    }
}



http.createServer((req,res)=>{
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Request-Method', '*');
    res.setHeader('Access-Control-Allow-Methods', 'OPTIONS, GET');
    res.setHeader('Access-Control-Allow-Headers', '*');

    const q=url.parse(req.url,true).query;
    let m=new Mitarbeiter(parseFloat(q.groesse),parseFloat(q.gewicht));
    res.end(JSON.stringify({isPraemie:m.isPraemie(), bmi:m.berecheBmi()}));
})
.listen(8080,()=>{
    console.log("Server is waiting...");
});

